public abstract class AbstractProgram3 {

    public abstract TownPlan OptimalRange(TownPlan town);

    public abstract TownPlan OptimalPosBaseStations(TownPlan town);
}
